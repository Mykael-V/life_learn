# telas/__init__.py
from .login import iniciar_login  # Exporta a função para iniciar a tela de login
from .selecao_exercicios import abrir_tela_selecao  # Exporta a função para abrir a tela de seleção