import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import os
from polichinelo_counter import contar_polichinelos  # Importa a lógica de contagem de polichinelos

def abrir_tela_selecao(usuario_id):  # Agora recebe o ID do usuário
    # Configuração da janela de seleção de exercícios
    selecao_window = tk.Tk()
    selecao_window.title(f"Life Learn - Bem-vindo, {usuario_id}!")  # Exibe o ID (ou nome, se preferir)
    selecao_window.geometry("800x600")
    selecao_window.resizable(False, False)

    # Carregar imagem de fundo
    caminho_background = os.path.join(os.path.dirname(__file__), "..", "assets", "background.jpg")
    caminho_background = os.path.abspath(caminho_background)
    background_image = Image.open(caminho_background)
    background_photo = ImageTk.PhotoImage(background_image)

    # Canvas para o fundo
    canvas = tk.Canvas(selecao_window, width=800, height=600, bg="#000000")  # Fundo preto
    canvas.pack(fill="both", expand=True)
    canvas.create_image(0, 0, image=background_photo, anchor="nw")

    # Manter uma referência à imagem para evitar que seja coletada pelo garbage collector
    canvas.background_photo = background_photo

    # Frame principal
    frame = tk.Frame(canvas, bg="#000000", bd=5, relief=tk.GROOVE)  # Fundo preto
    frame.place(relx=0.5, rely=0.5, anchor="center")

    # Título
    label_titulo = tk.Label(frame, text="Selecione o Exercício", font=("Arial", 24, "bold"), bg="#000000", fg="#ffffff")
    label_titulo.pack(pady=20)

    # Carregar imagens dos exercícios
    caminho_polichinelos = os.path.join(os.path.dirname(__file__), "..", "assets", "polichinelos.jpg")
    caminho_polichinelos = os.path.abspath(caminho_polichinelos)
    if not os.path.exists(caminho_polichinelos):
        print(f"Arquivo não encontrado: {caminho_polichinelos}")
    else:
        polichinelos_image = Image.open(caminho_polichinelos)
        polichinelos_image = polichinelos_image.resize((200, 200), Image.Resampling.LANCZOS)
        polichinelos_photo = ImageTk.PhotoImage(polichinelos_image)

        # Botão para Polichinelos
        btn_polichinelos = ttk.Button(
            frame,
            text="Polichinelos",
            style="TButton",
            command=lambda: contar_polichinelos(usuario_id),  # Passa o ID do usuário
            image=polichinelos_photo,  # Imagem do exercício
            compound="top"  # Texto abaixo da imagem
        )
        btn_polichinelos.image = polichinelos_photo  # Mantém uma referência para a imagem
        btn_polichinelos.pack(pady=20)

    # Estilo para os botões
    style = ttk.Style()
    style.configure("TButton", font=("Arial", 12), padding=10, background="#ffcc00", foreground="#000000")  # Botão amarelo

    selecao_window.mainloop()