import tkinter as tk
from tkinter import messagebox, ttk
from PIL import Image, ImageTk
import os
from db import verificar_usuario, registrar_login

def iniciar_login(fazer_login_callback):
    def fazer_login():
        nome = entry_usuario.get()

        if nome:
            usuario_id = verificar_usuario(nome)  # Verifica ou cria o usuário
            registrar_login(usuario_id)  # Registra o login
            messagebox.showinfo("Sucesso", f"Bem-vindo, {nome}!")
            root.destroy()  # Fecha a tela de login
            fazer_login_callback(usuario_id)  # Passa o ID do usuário para a função de callback
        else:
            messagebox.showerror("Erro", "Digite seu nome!")

    # Configuração da janela principal
    root = tk.Tk()
    root.title("Life Learn - Login")
    root.geometry("800x600")
    root.resizable(False, False)

    # Carregar imagens
    caminho_background = os.path.join(os.path.dirname(__file__), "..", "assets", "background.jpg")
    caminho_background = os.path.abspath(caminho_background)
    background_image = Image.open(caminho_background)
    background_photo = ImageTk.PhotoImage(background_image)

    # Caminho para o logo
    caminho_logo = os.path.join(os.path.dirname(__file__), "..", "assets", "logo.png")
    caminho_logo = os.path.abspath(caminho_logo)

    # Verifica se o arquivo do logo existe
    if not os.path.exists(caminho_logo):
        messagebox.showerror("Erro", f"Arquivo do logo não encontrado: {caminho_logo}")
        return

    logo_image = Image.open(caminho_logo)
    logo_image = logo_image.resize((200, 200), Image.Resampling.LANCZOS)
    logo_photo = ImageTk.PhotoImage(logo_image)

    # Canvas para o fundo
    canvas = tk.Canvas(root, width=800, height=600, bg="#000000")  # Fundo preto
    canvas.pack(fill="both", expand=True)
    canvas.create_image(0, 0, image=background_photo, anchor="nw")

    # Manter uma referência à imagem para evitar que seja coletada pelo garbage collector
    canvas.background_photo = background_photo

    # Frame principal
    frame = tk.Frame(canvas, bg="#000000", bd=5, relief=tk.GROOVE)  # Fundo preto
    frame.place(relx=0.5, rely=0.5, anchor="center")

    # Logo
    label_logo = tk.Label(frame, image=logo_photo, bg="#000000")  # Fundo preto
    label_logo.image = logo_photo  # Mantém uma referência para a imagem
    label_logo.grid(row=0, column=0, columnspan=2, pady=(20, 10))

    # Campo de usuário
    label_usuario = tk.Label(frame, text="Usuário:", font=("Arial", 12), bg="#000000", fg="#ffffff")  # Texto branco
    label_usuario.grid(row=1, column=0, padx=10, pady=5, sticky="e")

    entry_usuario = ttk.Entry(frame, width=20, font=("Arial", 12))
    entry_usuario.grid(row=1, column=1, padx=10, pady=5)

    # Botão de login
    btn_login = ttk.Button(frame, text="Entrar", style="TButton", command=fazer_login)
    btn_login.grid(row=2, column=0, columnspan=2, pady=20)

    # Estilo para os botões
    style = ttk.Style()
    style.configure("TButton", font=("Arial", 12), padding=10, background="#ffcc00", foreground="#000000")  # Botão amarelo

    root.mainloop()